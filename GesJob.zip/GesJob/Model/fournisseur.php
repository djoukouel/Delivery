<?php
	function addFournisseur($nom, $adr, $code, $ville){
		$sql = "INSERT INTO fournisseur VALUES(null, '$nom', '$adr', '$code', '$ville')";
		return executeSQL($sql);
	}

	function listFournisseur(){
		$sql = "SELECT * FROM fournisseur";
		return executeSQL($sql);
	}

	function deleteFournisseur($idf){
		$sql = "DELETE FROM fournisseur WHERE idf = $idf";
		return executeSQL($sql);
	}

	function updateFournisseur($idf, $nomf, $adrf, $codpf, $villef){
		$sql = "UPDATE fournisseur SET nomf='$nomf', adrf='$adrf', codpf='$codpf', villef='$villef' WHERE idf='$idf'";
		return executeSQL($sql);
	}

	function getFournisseur($idf){
		$sql = "SELECT * FROM fournisseur WHERE idf='$idf'";
		return executeSQL($sql);
	}
?>