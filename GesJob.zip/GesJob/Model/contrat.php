<?php
	function addContrat($datec, $qtcn, $signe, $idf){
		$sql = "INSERT INTO contrat VALUES(null, '$datec', $qtcn, $signe, $idf)";
		return executeSQL($sql);
	}

	function listContrat(){
		$sql = "SELECT * FROM contrat";
		return executeSQL($sql);
	}

	function updateContrat($idc, $date, $qten, $signe, $idf){
		$sql = "UPDATE contrat SET datec='$date', qtcn='$qten', signe='$signe', idf='$idf' WHERE idc='$idc'";
		return executeSQL($sql);
	}

	function getContratById($idc){
		$sql = "SELECT * FROM contrat WHERE idc='$idc '";
		return executeSQL($sql);
	}

	function deleteContrat($idc){
		$sql = "DELETE FROM contrat WHERE idf = $idc";
		return executeSQL($sql);
	}
?>