<?php
	require_once '../Model/db.php';
	require_once '../Model/contrat.php';
	if (isset($_POST['valider'])) {
		$date = $_POST['datec'];
		$qten = $_POST['qtcn'];
		$signe = $_POST['signe'];
		$f = $_POST['idf'];
		addContrat($date, $qten, $signe, $f);
		header("location:http://localhost/GesJob/?ok=listc");
	}

	//Update contrat 
	if (isset($_POST['modif'])) {
		$id = $_POST['idc'];
		$date = $_POST['datec'];
		$qten = $_POST['qten'];
		$signe = $_POST['signe'];
		$f = $_POST['idf'];
		updateContrat($id, $date, $qten, $signe, $f);
		header("location:http://localhost/GesJob/?ok=listc");
	}

	//suppression  
	if (isset($_GET['idc'])) {
		deleteContrat($_GET['idc']); 
		header("location:http://localhost/GesJob/?ok=listc");
	}
?> 