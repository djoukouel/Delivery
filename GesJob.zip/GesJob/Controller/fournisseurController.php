<?php
	require_once '../Model/db.php';
	require_once '../Model/fournisseur.php';
	if (isset($_POST['valider'])) {
		$nom = $_POST['nomf'];
		$adr = $_POST['adrf'];
		$code = $_POST['codpf'];
		$ville = $_POST['villef'];
		addFournisseur($nom, $adr, $code, $ville);
		header("location:http://localhost/GesJob/?ok=listf");
	}

	//suppression  
	if (isset($_GET['idf'])) {
		deleteFournisseur($_GET['idf']); 
		header("location:http://localhost/GesJob/?ok=listf");
	}

	//Modfication
	if (isset($_POST['modif'])) {
		$idf = $_POST['idf'];
		$nom = $_POST['nomf'];
		$adr = $_POST['adrf'];
		$code = $_POST['codpf'];
		$ville = $_POST['villef'];
		updateFournisseur($idf, $nom, $adr, $code, $ville);
		header("location:http://localhost/GesJob/?ok=listf");
	}
?>