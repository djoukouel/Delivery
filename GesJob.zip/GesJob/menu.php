<!DOCTYPE html>
<html>
<head>
	<title>Menu</title>
	<link rel="stylesheet" type="text/css" href="./Style/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="./Style/style.css">
</head>
<body>
	<div class="nav navbar-default">
		<div class="container-fluid">
			<ul class="nav navbar-nav">
				<li><a href="">Accueil</a></li>
				<li><a href="?ok=addf">Ajout fournisseur</a></li>
				<li><a href="?ok=listf">Liste fournisseur</a></li>
				<li><a href="?ok=addc">Ajout contrat</a></li>
				<li><a href="?ok=listc">Liste contrat</a></li>
			</ul>
		</div>
	</div>
</body>
</html>