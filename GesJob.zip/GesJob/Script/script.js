function confirmation(){
	return confirm("Voulez-vous vraiment supprimer cet element ?");
}