<?php
	if (isset($_GET['ok'])) {
		require_once 'menu.php';
		switch ($_GET['ok']) {
			//TABLE FOURNISSEUR
			case 'addf':
				require_once 'View/fournisseur/add.php';
				break;
			case 'listf':
				require_once 'Model/db.php';
				require_once 'Model/fournisseur.php';
				$link = listFournisseur();
				require_once 'View/fournisseur/list.php';
				break;
			case 'editf':
				require_once 'Model/db.php';
				require_once 'Model/fournisseur.php';
				$tab = getFournisseur($_GET['dif']);
				$ligne = mysqli_fetch_row($tab);
				require_once 'View/fournisseur/edit.php'; 
				break;

			//TABLE CONTRAT
			case 'addc':
				require_once 'View/contrat/add.php';
				break;
			case 'listc':
				require_once 'Model/db.php';
				require_once 'Model/contrat.php';
				$link = listContrat();
				require_once 'View/contrat/list.php';
				break;
			case 'editc':
				require_once 'Model/db.php';
				require_once 'Model/contrat.php';
				$tab = getContratById($_GET['idc']);
				$ligne = mysqli_fetch_row($tab);
				require_once 'View/contrat/edit.php'; 
				break;
		}
	}
	else{
		require_once 'menu.php';
	}
?>