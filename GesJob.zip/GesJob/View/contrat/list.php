<!DOCTYPE html>
<html>
<head>
	<title>Liste Fournisseur</title>
	<link rel="stylesheet" type="text/css" href="./Style/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="./Style/style.css">
	<script type="text/javascript" src="./Script/script.js"></script>
</head>
<body>
	<div class="container spacer col-md-6">
		<div class="panel panel-info">
			<div class="panel-hesding">Liste des fournisseurs ajoutes</div>
			<div class="panel-body">
				<table class="table table-hover">
					<tr>
						<th>Identifiant</th> 
						<th>Date Contrat</th>
						<th>Quantite</th>
						<th>Signature</th>
						<th>Fournisseur</th>
						<th>Action 1</th>
						<th>Action 2</th>
					</tr>
					<tr>
						<?php
							while ($cont = mysqli_fetch_row($link)) {
								echo "<tr>
										<td>$cont[0]</td>
										<td>$cont[1]</td>
										<td>$cont[2]</td>
										<td>$cont[3]</td>
										<td>$cont[4]</td>
										<td><a href='Controller/contratController.php?idc=$cont[0]' class='btn btn-danger' onclick = 'return confirmation();'>Supprimer</a></td>
										<td><a href='?ok=editc&idc=$cont[0]' class='btn btn-primary'>Editer</a></td>
									</tr>";
							}
						?>
					</tr>
				</table>
			</div>
		</div>
	</div>
</body>  
</html>