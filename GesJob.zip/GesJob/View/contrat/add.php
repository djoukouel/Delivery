<!DOCTYPE html>
<html>
<head>
	<title>Ajout contrat</title>
	<link rel="stylesheet" type="text/css" href="./Style/bootstrap.css">
	<link rel="stylesheet" type="text/css" href=".Style/style.css">
</head>
<body>
	<div class="container col-md-6 spacer">
		<div class="panel panel-info">
			<div class="panel-heading">Formulaire d'ajout de contrat</div>
			<div class="panel-body">
				<form method="POST" action="Controller/contratController.php">
					<div class="form-group">
						<label class="control-label">DATE</label>
						<input type="date" name="datec" class="form-control">
					</div>
					<div class="form-group">
						<label class="control-label">QUANTITE</label>
						<input type="number" name="qtcn" class="form-control">
					</div>
					<div class="form-group">
						<label class="control-label">SIGNE</label>
						<select class="form-control" name="signe">
							<option value="1">Oui</option>
							<option value="0">Non</option>
						</select>
					</div>
					<div class="form-group">
						<label class="control-label">FOURNISSEUR</label>
						<select class="form-control" name="idf">
							<option>Faites votre choix</option>
							<?php
								require_once 'Model/db.php';
								require_once 'Model/fournisseur.php';
								$list = listFournisseur();

								while ($ligne=mysqli_fetch_row($list)) {
									echo "<option value='$ligne[0]'>$ligne[1]</option>";
								}
							?>
						</select>
					</div>
					<button class="btn btn-success" name="valider" type="submit">Ajouter</button>
					<button class="btn btn-danger" name="refuser" type="reset"> Annuler</button>
				</form>
			</div>
		</div>
	</div>
</body>
</html>