<!DOCTYPE html>
<html>
<head>
	<title>Ajout fournisseur</title>
	<link rel="stylesheet" type="text/css" href="./Style/bootstrap.css">
	<link rel="stylesheet" type="text/css" href=".Style/style.css">
</head>
<body>
	<div class="container col-md-6 spacer">
		<div class="panel panel-info">
			<div class="panel-heading">Formulaire d'ajout de fournisseurs</div>
			<div class="panel-body">
				<form method="POST" action="Controller/fournisseurController.php">
					<div class="form-group">
						<label class="control-label">Nom</label>
						<input type="text" name="nomf" class="form-control">
					</div>
					<div class="form-group">
						<label class="control-label">Adresse</label>
						<input type="text" name="adrf" class="form-control">
					</div>
					<div class="form-group">
						<label class="control-label">Code postal</label>
						<input type="text" name="codpf" class="form-control">
					</div>
					<div class="form-group">
						<label class="control-label">Ville</label>
						<input type="text" name="villef" class="form-control">
					</div>
					<button class="btn btn-success" name="valider" type="submit">Ajouter</button>
					<button class="btn btn-danger" name="refuser" type="reset"> Annuler</button>
				</form>
			</div>
		</div>
	</div>
</body>
</html>