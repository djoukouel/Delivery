<!DOCTYPE html>
<html>
<head>
	<title>Editer fournisseur</title>
	<link rel="stylesheet" type="text/css" href="./Style/bootstrap.css">
	<link rel="stylesheet" type="text/css" href=".Style/style.css">
</head>
<body>
	<div class="container col-md-6 spacer">
		<div class="panel panel-info">
			<div class="panel-heading">Formulaire d'edition de fournisseurs</div>
			<div class="panel-body">
				<form method="POST" action="Controller/fournisseurController.php">
					<div class="form-group">
						<label class="control-label">Identifiant</label>
						<input type="text" name="idf" class="form-control" value="<?php echo $ligne[0];?>" readonly="readonly">
					</div>
					<div class="form-group">
						<label class="control-label">Nom</label>
						<input type="text" name="nomf" class="form-control" value="<?php echo $ligne[1];?>">
					</div>
					<div class="form-group">
						<label class="control-label">Adresse</label>
						<input type="text" name="adrf" class="form-control" value="<?php echo $ligne[2];?>">
					</div>
					<div class="form-group">
						<label class="control-label">Code postal</label>
						<input type="text" name="codpf" class="form-control" value="<?php echo $ligne[3];?>">
					</div>
					<div class="form-group">
						<label class="control-label">Ville</label>
						<input type="text" name="villef" class="form-control" value="<?php echo $ligne[4];?>">
					</div>
					<button class="btn btn-success" name="modif" type="submit">Modifier</button>
					<button class="btn btn-danger" name="refuser" type="reset"> Annuler</button>
				</form>
			</div>
		</div>
	</div>
</body>
</html>