<!DOCTYPE html>
<html>
<head>
	<title>Liste Fournisseur</title>
	<link rel="stylesheet" type="text/css" href="./Style/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="./Style/style.css">
	<script type="text/javascript" src="./Script/script.js"></script>
</head>
<body>
	<div class="container spacer col-md-6">
		<div class="panel panel-info">
			<div class="panel-hesding">Liste des fournisseurs ajoutes</div>
			<div class="panel-body">
				<table class="table table-hover">
					<tr>
						<th>Identifiant</th> 
						<th>nom</th>
						<th>Adresse</th>
						<th>Code</th>
						<th>Ville</th>
						<th>Action 1</th>
						<th>Action 2</th>
					</tr>
					<tr>
						<?php
							while ($svg = mysqli_fetch_row($link)) {
								echo "<tr>
										<td>$svg[0]</td>
										<td>$svg[1]</td>
										<td>$svg[2]</td>
										<td>$svg[3]</td>
										<td>$svg[4]</td>
										<td><a href='Controller/fournisseurController.php?idf=$svg[0]' class='btn btn-danger' onclick = 'return confirmation();'>Supprimer</a></td>
										<td><a href='?ok=editf&dif=$svg[0]' class='btn btn-primary'>Editer</a></td>
									</tr>";
							}
						?>
					</tr>
				</table>
			</div>
		</div>
	</div>
</body>  
</html>